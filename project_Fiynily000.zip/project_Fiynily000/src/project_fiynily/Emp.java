/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_fiynily;

import java.util.Date;
public class Emp {

    private int Emp_id,Mis_id,Emp_id_card;
    private String Emp_name,Emp_gn,Emp_nat,Emp_qua;
   private Date Emp_bd,Emp_dec,Emp_eff;
    private float Emp_amo;
    
  public Emp(int Emp_id,String Emp_name,Date Emp_bd,String Emp_gn,int Mis_id
          ,float Emp_amo,Date Emp_dec,Date Emp_eff,int Emp_id_card,String Emp_nat,
          String Emp_qua ){
      this.Emp_id=Emp_id;
      this.Emp_name=Emp_name;
      this.Emp_bd=Emp_bd;
      this.Emp_gn=Emp_gn;
      this.Mis_id=Mis_id;
      this.Emp_amo=Emp_amo;
      this.Emp_dec=Emp_dec;
      this.Emp_eff=Emp_eff;
      this.Emp_id_card=Emp_id_card;
      this.Emp_nat=Emp_nat;
      this.Emp_qua=Emp_qua;
  }

 
  public int getEmp_id(){
      return Emp_id;
  }
   public String getEmp_name(){
      return Emp_name;
  }
     public Date getEmp_bd(){
      return Emp_bd;
  }
       public String getEmp_gn(){
      return Emp_gn;
  }
         public int getMis_id(){
      return Mis_id;
  }
           public float getEmp_amo(){
      return Emp_amo;
  }
             public Date getEmp_dec(){
      return Emp_dec;
  }
               public Date getEmp_eff(){
      return Emp_eff;
  }
                 public int getEmp_id_card(){
      return Emp_id_card;
  }
                   public String getEmp_nat(){
      return Emp_nat;
  }
                     public String getEmp_qua(){
      return Emp_qua;
  }
   
  
}
    
