
package project_fiynily;

import java.util.Date;


public class Rew {
 
    private int Rew_id;
private String Rew__name;
private Date Rew_data;
private int Emp_id;
private float Rew_amo;
public Rew (int Rew_id, String Rew__name, Date Rew_data, int Emp_id,float Rew_amo){
this.Rew_id=Rew_id;
this.Rew__name=Rew__name;
this.Rew_data=Rew_data;
this.Emp_id=Emp_id;
this.Rew_amo=Rew_amo;
}
public int getRew_id(){
return Rew_id;
}
public String getRew__name(){
return Rew__name;
}
public Date getRew_data(){
return Rew_data;
}
public int getEmp_id(){
return Emp_id;
}
public float getRew_amo(){
return Rew_amo;
}
}

  
