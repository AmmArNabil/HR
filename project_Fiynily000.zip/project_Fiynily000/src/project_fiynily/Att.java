
package project_fiynily;

import java.util.Date;

public class Att {   
    private int Att_id;
private String Att__name;
private Date Att_data;
private int Emp_id;
private float Att_amo;
public Att (int Att_id, String Att__name, Date Att_data, int Emp_id,float Att_amo){
this.Att_id=Att_id;
this.Att__name=Att__name;
this.Att_data=Att_data;
this.Emp_id=Emp_id;
this.Att_amo=Att_amo;
}
public int getAtt_id(){
return Att_id;
}
public String getAtt__name(){
return Att__name;
}
public Date getAtt_data(){
return Att_data;
}
public int getEmp_id(){
return Emp_id;
}
public float getAtt_amo(){
return Att_amo;
} 
}
