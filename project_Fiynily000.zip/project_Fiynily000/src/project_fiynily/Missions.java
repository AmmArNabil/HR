
package project_fiynily;

public class Missions {
        private int Mis_id,Sal_id;
private String Mis_name;

public Missions (int Mis_id, String Mis_name,int Sal_id ){
this.Mis_id=Mis_id;
this.Mis_name=Mis_name;
this.Sal_id=Sal_id;

}
public int getMis_id(){
return Mis_id;
}
public String getMis_name(){
return Mis_name;
}
public int getSal_id(){
return Sal_id;
}

}
    

