
package project_fiynily;


public class Missions_all {
            private int Mis_id;
private String Emp_name,Mis_name;

public Missions_all (String Emp_name ,int Mis_id ,String Mis_name ){

    this.Emp_name=Emp_name;
    this.Mis_id=Mis_id;
    this.Mis_name=Mis_name;

}
public String getEmp_name(){
return Emp_name;
}
public int getMis_id(){
return Mis_id;
}
public String getMis_name(){
return Mis_name;
}



}
