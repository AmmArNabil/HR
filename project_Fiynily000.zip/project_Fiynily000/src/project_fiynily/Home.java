/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_fiynily;

import java.awt.Color;
import javax.swing.JPanel;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Date;
import java.util.GregorianCalendar;
import java.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.tree.ExpandVetoException;

public class Home extends javax.swing.JFrame {
static Connection can=null;
static  PreparedStatement pat=null;
static  ResultSet rs=null;
static Statement st=null;
static String u="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
  String gender;
  String name;
// static GregorianCalendar gc=new GregorianCalendar();
 
 
     
       
    public Home(String name1) {
        initComponents();
           pa_Benefits.setVisible(false);
   
                   name = name1;
       jLabel9.setText("Welcome Admin  ("+name1+")");
    
   pa_sal.setVisible(false);
   pa_emp.setVisible(false);
     pa_add_new_emp.setVisible(false); 
     pa_d_emp.setVisible(false);
          pa_em_sea.setVisible(false);
          pa_miss_h.setVisible(false);
            jp_rew_att.setVisible(false);
 String pattern = "yyyy-MM-dd";
SimpleDateFormat format = new SimpleDateFormat(pattern);
     Date date = new Date();
 
        // جديدة لإظهار الوقت format هنا قمنا بإنشاء
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
 
        // ثم قمنا بعرض النتيجة format من خلال الدالة date على الـ format هنا قمنا بتطبيق الـ
      //  System.out.println( sdf.format(date) );
        jLabel77.setText(sdf.format(date).toString());
            
 
        // هنا قمنا بعرض التاريخ فقط
      
 // p_emp.setVisible(false);
// jPanel3.setVisible(false);
    }
   // 
//public Home() {
//       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//public Home(String name) {
  //      throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}

       public void claertext(){
  jTextField4.setText(null);
       jTextField5.setText(null);
           jTextField6.setText(null);
               jTextField7.setText(null);
    }
        void setVisible(JPanel panel1){
            panel1.setVisible(true);
        }
         void resrtVisible(JPanel panel1){
            panel1.setVisible(false);
        }
   
        
        void setColor(JPanel panel){
            panel.setBackground(new Color(85,65,100));
        }
      
       
          void resrtColor(JPanel panel){
               panel.setBackground(new Color(64,43,118)); 
        } 
              void setColorr(JPanel panel){
            panel.setBackground(new Color(134,111,111));
        }
      
       
          void resrtColorr(JPanel panel){
               panel.setBackground(new Color(73,59,59)); 
        } 

    
    @SuppressWarnings("unchecked")
          
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        bg = new javax.swing.JPanel();
        s = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btn_do = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btn_em = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btn_inc = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btn_com = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        btn_ad = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        pa_sal = new java.awt.Panel();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt_sal = new javax.swing.JTable();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        pa_emp = new javax.swing.JPanel();
        pa_add_new_emp = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        s1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        btn_do1 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btn_em1 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btn_inc1 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        btn_com1 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        btn_ad1 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        pa_d_emp = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable8 = new javax.swing.JTable();
        pa_em_sea = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jTextField15 = new javax.swing.JTextField();
        pa_miss_h = new javax.swing.JPanel();
        pa_mis = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        btn_do2 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        btn_inc2 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        btn_ad2 = new javax.swing.JPanel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        btn_ad3 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        pa_mis_add = new javax.swing.JPanel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel71 = new javax.swing.JLabel();
        jcom_mis_id = new javax.swing.JComboBox<>();
        pa_mis_del = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        jt12 = new javax.swing.JTable();
        pa_mis_sea = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jt_sea_mis_all = new javax.swing.JTable();
        pa_Benefits = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jp_rew_att = new javax.swing.JPanel();
        pa_mis1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        btn_do3 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        btn_inc3 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        btn_ad5 = new javax.swing.JPanel();
        jLabel78 = new javax.swing.JLabel();
        jpa_rew = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jTextField18_rew = new javax.swing.JTextField();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jTextField21_rew = new javax.swing.JTextField();
        jLabel79 = new javax.swing.JLabel();
        jTextField22_rew = new javax.swing.JTextField();
        jLabel80 = new javax.swing.JLabel();
        jComboBox1_rew = new javax.swing.JComboBox<>();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jComboBox5 = new javax.swing.JComboBox<>();
        jpa_att = new javax.swing.JPanel();
        jLabel81 = new javax.swing.JLabel();
        jTextField23_att = new javax.swing.JTextField();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jTextField24_att = new javax.swing.JTextField();
        jLabel84 = new javax.swing.JLabel();
        jTextField25_att = new javax.swing.JTextField();
        jLabel85 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jComboBox6 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setMinimumSize(new java.awt.Dimension(1070, 590));
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setAutoscrolls(true);
        bg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                bgMouseDragged(evt);
            }
        });
        bg.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                bgFocusLost(evt);
            }
        });
        bg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                bgMousePressed(evt);
            }
        });
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        s.setBackground(new java.awt.Color(73, 59, 59));
        s.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(85, 55, 118));
        jPanel2.setLayout(new java.awt.BorderLayout());
        s.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 240, -1));

        btn_do.setBackground(new java.awt.Color(73, 59, 59));
        btn_do.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_doMousePressed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/money (1).png"))); // NOI18N

        jLabel1.setBackground(new java.awt.Color(54, 33, 89));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1.setText("الرواتب");

        javax.swing.GroupLayout btn_doLayout = new javax.swing.GroupLayout(btn_do);
        btn_do.setLayout(btn_doLayout);
        btn_doLayout.setHorizontalGroup(
            btn_doLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_doLayout.createSequentialGroup()
                .addContainerGap(172, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_doLayout.setVerticalGroup(
            btn_doLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_doLayout.createSequentialGroup()
                .addGroup(btn_doLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_doLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)))
                .addContainerGap())
        );

        s.add(btn_do, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 290, -1));

        btn_em.setBackground(new java.awt.Color(73, 59, 59));
        btn_em.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_emMousePressed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/home (3).png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("الرئيسية");

        javax.swing.GroupLayout btn_emLayout = new javax.swing.GroupLayout(btn_em);
        btn_em.setLayout(btn_emLayout);
        btn_emLayout.setHorizontalGroup(
            btn_emLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_emLayout.createSequentialGroup()
                .addContainerGap(168, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(35, 35, 35)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_emLayout.setVerticalGroup(
            btn_emLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_emLayout.createSequentialGroup()
                .addGroup(btn_emLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_emLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4)))
                .addContainerGap())
        );

        s.add(btn_em, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 290, -1));

        btn_inc.setBackground(new java.awt.Color(73, 59, 59));
        btn_inc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_incMousePressed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/gift (1).png"))); // NOI18N

        jLabel6.setBackground(new java.awt.Color(54, 33, 89));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("المكافأت والخصومات");

        javax.swing.GroupLayout btn_incLayout = new javax.swing.GroupLayout(btn_inc);
        btn_inc.setLayout(btn_incLayout);
        btn_incLayout.setHorizontalGroup(
            btn_incLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_incLayout.createSequentialGroup()
                .addContainerGap(86, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(39, 39, 39)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_incLayout.setVerticalGroup(
            btn_incLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_incLayout.createSequentialGroup()
                .addGroup(btn_incLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_incLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)))
                .addContainerGap())
        );

        s.add(btn_inc, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 290, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("AMMAR_NABIL");
        s.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        btn_com.setBackground(new java.awt.Color(73, 59, 59));
        btn_com.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_comMousePressed(evt);
            }
        });

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/employee (2).png"))); // NOI18N

        jLabel11.setBackground(new java.awt.Color(54, 33, 89));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(204, 204, 204));
        jLabel11.setText("الموظفين");

        javax.swing.GroupLayout btn_comLayout = new javax.swing.GroupLayout(btn_com);
        btn_com.setLayout(btn_comLayout);
        btn_comLayout.setHorizontalGroup(
            btn_comLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_comLayout.createSequentialGroup()
                .addContainerGap(155, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(39, 39, 39)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_comLayout.setVerticalGroup(
            btn_comLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_comLayout.createSequentialGroup()
                .addGroup(btn_comLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_comLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel11)))
                .addContainerGap())
        );

        s.add(btn_com, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 290, -1));

        btn_ad.setBackground(new java.awt.Color(73, 59, 59));
        btn_ad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_adMousePressed(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/jobb.png"))); // NOI18N

        jLabel13.setBackground(new java.awt.Color(54, 33, 89));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(204, 204, 204));
        jLabel13.setText("الوظائف");

        javax.swing.GroupLayout btn_adLayout = new javax.swing.GroupLayout(btn_ad);
        btn_ad.setLayout(btn_adLayout);
        btn_adLayout.setHorizontalGroup(
            btn_adLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_adLayout.createSequentialGroup()
                .addContainerGap(163, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(37, 37, 37)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_adLayout.setVerticalGroup(
            btn_adLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_adLayout.createSequentialGroup()
                .addGroup(btn_adLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_adLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel13)))
                .addContainerGap())
        );

        s.add(btn_ad, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 270, 290, -1));

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        s.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 170, 10));

        bg.add(s, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, 290, 696));

        jPanel3.setBackground(new java.awt.Color(134, 111, 111));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 192, 32));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 204));
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 40, 10));

        jLabel74.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(204, 204, 204));
        jLabel74.setText("سجل المعاملات لـ");
        jPanel3.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 11, -1, -1));

        bg.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 820, 90));

        pa_sal.setBackground(new java.awt.Color(240, 240, 240));
        pa_sal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/delete.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        pa_sal.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(325, 446, 37, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/updated001.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        pa_sal.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 446, 37, -1));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/save.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        pa_sal.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(435, 446, 37, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/add-file (2).png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        pa_sal.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 446, 37, -1));

        jTextField4.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField4.setForeground(new java.awt.Color(73, 59, 59));
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_sal.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, 430, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(73, 59, 59));
        jLabel18.setText("الرواتب");
        pa_sal.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 40, -1, -1));

        jTextField5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField5.setForeground(new java.awt.Color(73, 59, 59));
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_sal.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 160, 110, -1));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(73, 59, 59));
        jLabel19.setText("الراتب");
        pa_sal.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 160, -1, -1));

        jTextField6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField6.setForeground(new java.awt.Color(73, 59, 59));
        jTextField6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_sal.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, 105, -1));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(73, 59, 59));
        jLabel20.setText("العلاوة");
        pa_sal.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, -1, -1));

        jTextField7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField7.setForeground(new java.awt.Color(73, 59, 59));
        jTextField7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_sal.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 106, -1));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(73, 59, 59));
        jLabel21.setText("بدل النقل");
        pa_sal.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 200, -1, -1));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jt_sal.setAutoCreateRowSorter(true);
        jt_sal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jt_sal.setForeground(new java.awt.Color(73, 59, 59));
        jt_sal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "                    رقم الرتبة", "اسم الرتبة", "الراتب", "العلاوة", "النقل"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class, java.lang.Float.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jt_sal.setGridColor(new java.awt.Color(255, 255, 255));
        jt_sal.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jt_sal.setRowHeight(25);
        jt_sal.setSelectionBackground(new java.awt.Color(134, 111, 111));
        jt_sal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jt_salMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jt_sal);
        if (jt_sal.getColumnModel().getColumnCount() > 0) {
            jt_sal.getColumnModel().getColumn(0).setMinWidth(20);
            jt_sal.getColumnModel().getColumn(0).setMaxWidth(30);
        }

        pa_sal.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 780, 170));

        jLabel69.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(73, 59, 59));
        jLabel69.setText("اسم الرتبة");
        pa_sal.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 120, -1, -1));

        jLabel70.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/money (2)_1.png"))); // NOI18N
        pa_sal.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 30, -1, -1));

        bg.add(pa_sal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 780, 510));

        jLabel14.setBackground(new java.awt.Color(64, 43, 100));
        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/xx.png"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });
        bg.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        pa_emp.setBackground(new java.awt.Color(204, 255, 255));
        pa_emp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pa_add_new_emp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(73, 59, 59));
        jLabel25.setText("الأسم");
        pa_add_new_emp.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 113, -1, -1));

        jTextField8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField8.setForeground(new java.awt.Color(73, 59, 59));
        jTextField8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 290, -1));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(73, 59, 59));
        jLabel30.setText("تاريخ الميلاد");
        pa_add_new_emp.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, -1, -1));

        jTextField9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField9.setForeground(new java.awt.Color(73, 59, 59));
        jTextField9.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, 150, -1));

        buttonGroup2.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(73, 59, 59));
        jRadioButton1.setText("ذكر");
        jRadioButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jRadioButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/man.png"))); // NOI18N
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, -1, -1));

        buttonGroup2.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(73, 59, 59));
        jRadioButton2.setText("انثى");
        jRadioButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/girl.png"))); // NOI18N
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, -1, -1));

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(73, 59, 59));
        jLabel31.setText("اسم الوظيفة");
        pa_add_new_emp.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, -1, -1));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(73, 59, 59));
        jLabel32.setText("رقم البطاقة الشخصية");
        pa_add_new_emp.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, -1, -1));

        jTextField10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField10.setForeground(new java.awt.Color(73, 59, 59));
        jTextField10.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 310, 120, -1));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(73, 59, 59));
        jLabel33.setText("الراتب");
        pa_add_new_emp.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 310, -1, -1));

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(73, 59, 59));
        jLabel34.setText("تاريخ السريان");
        pa_add_new_emp.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, -1, -1));

        jTextField11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField11.setForeground(new java.awt.Color(73, 59, 59));
        jTextField11.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 350, 140, -1));

        jTextField12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField12.setForeground(new java.awt.Color(73, 59, 59));
        jTextField12.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 145, -1));

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(73, 59, 59));
        jLabel35.setText("تاريخ القرار");
        pa_add_new_emp.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 350, 70, -1));

        jTextField13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField13.setForeground(new java.awt.Color(73, 59, 59));
        jTextField13.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, 200, -1));

        jComboBox2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(73, 59, 59));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 120, -1));

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/add (1).png"))); // NOI18N
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, -1, -1));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/accept.png"))); // NOI18N
        jButton6.setBorder(null);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 470, -1, -1));

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/multiply.png"))); // NOI18N
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 470, -1, -1));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/employee (4).png"))); // NOI18N
        pa_add_new_emp.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(73, 59, 59));
        jLabel37.setText("اضافة موظف");
        pa_add_new_emp.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, -1, -1));

        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(73, 59, 59));
        jLabel58.setText("المؤهلات العلمية");
        pa_add_new_emp.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 390, -1, -1));

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(73, 59, 59));
        jLabel66.setText("الجنس");
        pa_add_new_emp.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, -1, -1));

        jCheckBox1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(73, 59, 59));
        jCheckBox1.setText("يقراء ويكتب");
        pa_add_new_emp.add(jCheckBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 420, -1, -1));

        jCheckBox2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jCheckBox2.setForeground(new java.awt.Color(73, 59, 59));
        jCheckBox2.setText("ثانوي");
        pa_add_new_emp.add(jCheckBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 420, -1, -1));

        jCheckBox3.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jCheckBox3.setForeground(new java.awt.Color(73, 59, 59));
        jCheckBox3.setText("بكالوريس");
        pa_add_new_emp.add(jCheckBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, -1, -1));

        jCheckBox4.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jCheckBox4.setForeground(new java.awt.Color(73, 59, 59));
        jCheckBox4.setText("ماجستير");
        pa_add_new_emp.add(jCheckBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, -1, -1));

        jCheckBox5.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jCheckBox5.setForeground(new java.awt.Color(73, 59, 59));
        jCheckBox5.setText("دكتوراه");
        pa_add_new_emp.add(jCheckBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, -1, -1));

        jComboBox3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox3.setForeground(new java.awt.Color(73, 59, 59));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });
        pa_add_new_emp.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 270, 70, -1));

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(73, 59, 59));
        jLabel67.setText("رقم الوظيفة");
        pa_add_new_emp.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 270, -1, -1));

        jLabel68.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(73, 59, 59));
        jLabel68.setText("الجنسية");
        pa_add_new_emp.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, -1, -1));

        jTextField16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField16.setForeground(new java.awt.Color(73, 59, 59));
        jTextField16.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_add_new_emp.add(jTextField16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 120, -1));

        pa_emp.add(pa_add_new_emp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 510));

        s1.setBackground(new java.awt.Color(73, 59, 59));

        jPanel4.setBackground(new java.awt.Color(85, 55, 118));
        jPanel4.setLayout(new java.awt.BorderLayout());

        btn_do1.setBackground(new java.awt.Color(73, 59, 59));
        btn_do1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_do1MousePressed(evt);
            }
        });

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/employee (5).png"))); // NOI18N

        jLabel16.setBackground(new java.awt.Color(54, 33, 89));
        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(204, 204, 204));
        jLabel16.setText("اضافة موظف");

        javax.swing.GroupLayout btn_do1Layout = new javax.swing.GroupLayout(btn_do1);
        btn_do1.setLayout(btn_do1Layout);
        btn_do1Layout.setHorizontalGroup(
            btn_do1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_do1Layout.createSequentialGroup()
                .addContainerGap(74, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(28, 28, 28)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_do1Layout.setVerticalGroup(
            btn_do1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_do1Layout.createSequentialGroup()
                .addGroup(btn_do1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_do1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel16)))
                .addContainerGap())
        );

        btn_em1.setBackground(new java.awt.Color(73, 59, 59));
        btn_em1.setEnabled(false);
        btn_em1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_em1MousePressed(evt);
            }
        });

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/group.png"))); // NOI18N

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(204, 204, 204));
        jLabel22.setText("عرض جميع الموظفين");

        javax.swing.GroupLayout btn_em1Layout = new javax.swing.GroupLayout(btn_em1);
        btn_em1.setLayout(btn_em1Layout);
        btn_em1Layout.setHorizontalGroup(
            btn_em1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_em1Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addGap(27, 27, 27)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_em1Layout.setVerticalGroup(
            btn_em1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_em1Layout.createSequentialGroup()
                .addGroup(btn_em1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_em1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel22)))
                .addContainerGap())
        );

        btn_inc1.setBackground(new java.awt.Color(73, 59, 59));
        btn_inc1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_inc1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_inc1MousePressed(evt);
            }
        });

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/d_emmp.png"))); // NOI18N

        jLabel24.setBackground(new java.awt.Color(54, 33, 89));
        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(204, 204, 204));
        jLabel24.setText("حذف موظف");

        javax.swing.GroupLayout btn_inc1Layout = new javax.swing.GroupLayout(btn_inc1);
        btn_inc1.setLayout(btn_inc1Layout);
        btn_inc1Layout.setHorizontalGroup(
            btn_inc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_inc1Layout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addGap(30, 30, 30)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_inc1Layout.setVerticalGroup(
            btn_inc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_inc1Layout.createSequentialGroup()
                .addGroup(btn_inc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_inc1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel24)))
                .addContainerGap())
        );

        btn_com1.setBackground(new java.awt.Color(73, 59, 59));
        btn_com1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_com1MousePressed(evt);
            }
        });

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/employee (2).png"))); // NOI18N

        jLabel27.setBackground(new java.awt.Color(54, 33, 89));
        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(204, 204, 204));
        jLabel27.setText("الموظفين");

        javax.swing.GroupLayout btn_com1Layout = new javax.swing.GroupLayout(btn_com1);
        btn_com1.setLayout(btn_com1Layout);
        btn_com1Layout.setHorizontalGroup(
            btn_com1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_com1Layout.createSequentialGroup()
                .addContainerGap(95, Short.MAX_VALUE)
                .addComponent(jLabel27)
                .addGap(39, 39, 39)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_com1Layout.setVerticalGroup(
            btn_com1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_com1Layout.createSequentialGroup()
                .addGroup(btn_com1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_com1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel27)))
                .addContainerGap())
        );

        btn_ad1.setBackground(new java.awt.Color(73, 59, 59));
        btn_ad1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_ad1MousePressed(evt);
            }
        });

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/job-search.png"))); // NOI18N

        jLabel29.setBackground(new java.awt.Color(54, 33, 89));
        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(204, 204, 204));
        jLabel29.setText("البحث عن موظف");

        javax.swing.GroupLayout btn_ad1Layout = new javax.swing.GroupLayout(btn_ad1);
        btn_ad1.setLayout(btn_ad1Layout);
        btn_ad1Layout.setHorizontalGroup(
            btn_ad1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad1Layout.createSequentialGroup()
                .addContainerGap(53, Short.MAX_VALUE)
                .addComponent(jLabel29)
                .addGap(27, 27, 27)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        btn_ad1Layout.setVerticalGroup(
            btn_ad1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad1Layout.createSequentialGroup()
                .addGroup(btn_ad1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_ad1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel29)))
                .addContainerGap())
        );

        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N

        javax.swing.GroupLayout s1Layout = new javax.swing.GroupLayout(s1);
        s1.setLayout(s1Layout);
        s1Layout.setHorizontalGroup(
            s1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_com1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(s1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(btn_inc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(btn_do1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(btn_em1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(btn_ad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        s1Layout.setVerticalGroup(
            s1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(s1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(btn_com1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(s1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(s1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(s1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(btn_inc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_do1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(s1Layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(btn_em1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(s1Layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(btn_ad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        pa_emp.add(s1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 0, 230, 360));

        pa_d_emp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(73, 59, 59));
        jLabel38.setText("حذف موظف");
        pa_d_emp.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, -1, -1));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/d_eemp.png"))); // NOI18N
        pa_d_emp.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        jTextField14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField14.setForeground(new java.awt.Color(73, 59, 59));
        pa_d_emp.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 290, -1));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(73, 59, 59));
        jLabel40.setText("الأسم");
        pa_d_emp.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, -1, -1));

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/businessman (1).png"))); // NOI18N
        jButton8.setBorder(null);
        pa_d_emp.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/bin.png"))); // NOI18N
        jButton9.setBorder(null);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        pa_d_emp.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, -1, -1));

        jScrollPane8.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane8.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jTable8.setAutoCreateRowSorter(true);
        jTable8.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jTable8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "رقم", "اسم", "الراتب", "الجنس", "مرتبة", "الراتب", "التعين", "السريان", "البطاقة", "الجنسية", "مؤهل"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable8.setGridColor(new java.awt.Color(255, 255, 255));
        jTable8.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jTable8.setRowHeight(25);
        jTable8.setSelectionBackground(new java.awt.Color(134, 111, 111));
        jTable8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable8MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(jTable8);

        pa_d_emp.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 550, 200));

        pa_emp.add(pa_d_emp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 510));

        pa_em_sea.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/search_emp.png"))); // NOI18N
        pa_em_sea.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, -1, -1));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(73, 59, 59));
        jLabel42.setText("البحث عن موظف");
        pa_em_sea.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, -1, -1));

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(73, 59, 59));
        jLabel43.setText("الأسم");
        pa_em_sea.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 100, -1, -1));

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/businessman (1).png"))); // NOI18N
        jButton10.setBorder(null);
        jButton10.setFocusPainted(false);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        pa_em_sea.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, -1, -1));

        jScrollPane7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane7.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jTable7.setAutoCreateRowSorter(true);
        jTable7.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "رقم", "اسم", "الراتب", "الجنس", "مرتبة", "الراتب", "التعين", "السريان", "البطاقة", "الجنسية", "مؤهل"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable7.setGridColor(new java.awt.Color(255, 255, 255));
        jTable7.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jTable7.setRowHeight(25);
        jTable7.setSelectionBackground(new java.awt.Color(134, 111, 111));
        jTable7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable7MouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(jTable7);

        pa_em_sea.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 550, 200));

        jTextField15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField15.setForeground(new java.awt.Color(73, 59, 59));
        jTextField15.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_em_sea.add(jTextField15, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 290, -1));

        pa_emp.add(pa_em_sea, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 510));

        bg.add(pa_emp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 780, 510));

        pa_miss_h.setBackground(new java.awt.Color(204, 255, 255));
        pa_miss_h.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pa_mis.setBackground(new java.awt.Color(73, 59, 59));
        pa_mis.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(85, 55, 118));
        jPanel6.setLayout(new java.awt.BorderLayout());
        pa_mis.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 240, -1));

        btn_do2.setBackground(new java.awt.Color(73, 59, 59));
        btn_do2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_do2MousePressed(evt);
            }
        });

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/add_mis.png"))); // NOI18N

        jLabel45.setBackground(new java.awt.Color(54, 33, 89));
        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(204, 204, 204));
        jLabel45.setText("اضافة وظيفة");

        javax.swing.GroupLayout btn_do2Layout = new javax.swing.GroupLayout(btn_do2);
        btn_do2.setLayout(btn_do2Layout);
        btn_do2Layout.setHorizontalGroup(
            btn_do2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_do2Layout.createSequentialGroup()
                .addContainerGap(74, Short.MAX_VALUE)
                .addComponent(jLabel45)
                .addGap(28, 28, 28)
                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        btn_do2Layout.setVerticalGroup(
            btn_do2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_do2Layout.createSequentialGroup()
                .addGroup(btn_do2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_do2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel45)))
                .addContainerGap())
        );

        pa_mis.add(btn_do2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, -1, -1));

        btn_inc2.setBackground(new java.awt.Color(73, 59, 59));
        btn_inc2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_inc2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_inc2MousePressed(evt);
            }
        });

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/dele.png"))); // NOI18N

        jLabel49.setBackground(new java.awt.Color(54, 33, 89));
        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(204, 204, 204));
        jLabel49.setText("حذف وظيفة");

        javax.swing.GroupLayout btn_inc2Layout = new javax.swing.GroupLayout(btn_inc2);
        btn_inc2.setLayout(btn_inc2Layout);
        btn_inc2Layout.setHorizontalGroup(
            btn_inc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_inc2Layout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addComponent(jLabel49)
                .addGap(31, 31, 31)
                .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        btn_inc2Layout.setVerticalGroup(
            btn_inc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_inc2Layout.createSequentialGroup()
                .addGroup(btn_inc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_inc2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel49)))
                .addContainerGap())
        );

        pa_mis.add(btn_inc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, -1, -1));

        btn_ad2.setBackground(new java.awt.Color(73, 59, 59));
        btn_ad2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_ad2MousePressed(evt);
            }
        });

        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/search_job00.png"))); // NOI18N

        jLabel53.setBackground(new java.awt.Color(54, 33, 89));
        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(204, 204, 204));
        jLabel53.setText("عرض جميع الوظائف");

        javax.swing.GroupLayout btn_ad2Layout = new javax.swing.GroupLayout(btn_ad2);
        btn_ad2.setLayout(btn_ad2Layout);
        btn_ad2Layout.setHorizontalGroup(
            btn_ad2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel53)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        btn_ad2Layout.setVerticalGroup(
            btn_ad2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad2Layout.createSequentialGroup()
                .addGroup(btn_ad2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_ad2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel53)))
                .addContainerGap())
        );

        pa_mis.add(btn_ad2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, -1, -1));

        jSeparator3.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        pa_mis.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 170, 10));

        btn_ad3.setBackground(new java.awt.Color(73, 59, 59));
        btn_ad3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_ad3MousePressed(evt);
            }
        });

        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/jobb.png"))); // NOI18N

        jLabel55.setBackground(new java.awt.Color(54, 33, 89));
        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(204, 204, 204));
        jLabel55.setText("الوظائف");

        javax.swing.GroupLayout btn_ad3Layout = new javax.swing.GroupLayout(btn_ad3);
        btn_ad3.setLayout(btn_ad3Layout);
        btn_ad3Layout.setHorizontalGroup(
            btn_ad3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad3Layout.createSequentialGroup()
                .addContainerGap(95, Short.MAX_VALUE)
                .addComponent(jLabel55)
                .addGap(18, 18, 18)
                .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        btn_ad3Layout.setVerticalGroup(
            btn_ad3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad3Layout.createSequentialGroup()
                .addGroup(btn_ad3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(btn_ad3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel55)))
                .addContainerGap())
        );

        pa_mis.add(btn_ad3, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 19, -1, -1));

        pa_miss_h.add(pa_mis, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 0, 230, 400));

        pa_mis_add.setBackground(new java.awt.Color(204, 204, 204));
        pa_mis_add.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/briefcase.png"))); // NOI18N
        pa_mis_add.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(73, 59, 59));
        jLabel51.setText("اسم الوظيفة");
        pa_mis_add.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 140, -1, -1));

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(73, 59, 59));
        jLabel56.setText("اضافة وظيفة ");
        pa_mis_add.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, -1, -1));

        jTextField17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField17.setForeground(new java.awt.Color(73, 59, 59));
        jTextField17.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_mis_add.add(jTextField17, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 200, -1));

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/add (1).png"))); // NOI18N
        jButton11.setBorder(null);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        pa_mis_add.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 240, -1, -1));

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/multiply.png"))); // NOI18N
        jButton12.setBorder(null);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        pa_mis_add.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, -1, -1));

        jLabel71.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(73, 59, 59));
        jLabel71.setText("رقم المرتبة");
        pa_mis_add.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, -1, -1));

        jcom_mis_id.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jcom_mis_id.setForeground(new java.awt.Color(73, 59, 59));
        pa_mis_add.add(jcom_mis_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 180, 70, -1));

        pa_miss_h.add(pa_mis_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 550, 410));

        pa_mis_del.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/deledt_1.png"))); // NOI18N
        pa_mis_del.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, -1, -1));

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(73, 59, 59));
        jLabel60.setText("حذف وظيفة");
        pa_mis_del.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 80, -1, -1));

        jTextField19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField19.setForeground(new java.awt.Color(73, 59, 59));
        jTextField19.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pa_mis_del.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 120, 200, -1));

        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(73, 59, 59));
        jLabel61.setText("اسم الوظيفة");
        pa_mis_del.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 120, -1, -1));

        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/search0.png"))); // NOI18N
        jButton13.setBorder(null);
        pa_mis_del.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 49, -1));

        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/dele.png"))); // NOI18N
        jButton14.setBorder(null);
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        pa_mis_del.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, -1, -1));

        jScrollPane9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane9.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jt12.setAutoCreateRowSorter(true);
        jt12.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jt12.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "رقم الوظيفة", "اسم الوظيفة", "رقم الرتبة"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jt12.setGridColor(new java.awt.Color(255, 255, 255));
        jt12.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jt12.setRowHeight(25);
        jt12.setSelectionBackground(new java.awt.Color(134, 111, 111));
        jt12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jt12MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(jt12);
        if (jt12.getColumnModel().getColumnCount() > 0) {
            jt12.getColumnModel().getColumn(0).setMinWidth(100);
            jt12.getColumnModel().getColumn(0).setPreferredWidth(20);
            jt12.getColumnModel().getColumn(0).setMaxWidth(20);
            jt12.getColumnModel().getColumn(2).setMinWidth(100);
            jt12.getColumnModel().getColumn(2).setPreferredWidth(20);
            jt12.getColumnModel().getColumn(2).setMaxWidth(20);
        }

        pa_mis_del.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 540, 160));

        pa_miss_h.add(pa_mis_del, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 400));

        pa_mis_sea.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel62.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(73, 59, 59));
        jLabel62.setText("عرض جميع الوظائف");
        pa_mis_sea.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, -1, -1));

        jLabel63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/search_job1.png"))); // NOI18N
        pa_mis_sea.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, -1, -1));

        jScrollPane10.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane10.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jt_sea_mis_all.setAutoCreateRowSorter(true);
        jt_sea_mis_all.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jt_sea_mis_all.setForeground(new java.awt.Color(73, 59, 59));
        jt_sea_mis_all.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "اسم الموظف", "رقم الرتبة", "اسم الوظيفة"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jt_sea_mis_all.setGridColor(new java.awt.Color(255, 255, 255));
        jt_sea_mis_all.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jt_sea_mis_all.setRowHeight(25);
        jt_sea_mis_all.setSelectionBackground(new java.awt.Color(134, 111, 111));
        jt_sea_mis_all.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jt_sea_mis_allMouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(jt_sea_mis_all);
        if (jt_sea_mis_all.getColumnModel().getColumnCount() > 0) {
            jt_sea_mis_all.getColumnModel().getColumn(1).setMinWidth(100);
            jt_sea_mis_all.getColumnModel().getColumn(1).setPreferredWidth(20);
            jt_sea_mis_all.getColumnModel().getColumn(1).setMaxWidth(30);
        }

        pa_mis_sea.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 540, 240));

        pa_miss_h.add(pa_mis_sea, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 400));

        bg.add(pa_miss_h, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 780, 420));

        pa_Benefits.setBackground(new java.awt.Color(255, 255, 255));
        pa_Benefits.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        bg.add(pa_Benefits, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 780, 520));

        jLabel77.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(73, 59, 59));
        jLabel77.setText("التاريخ");
        bg.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 10, -1, -1));

        jp_rew_att.setBackground(new java.awt.Color(255, 204, 204));
        jp_rew_att.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pa_mis1.setBackground(new java.awt.Color(73, 59, 59));
        pa_mis1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(85, 55, 118));
        jPanel7.setLayout(new java.awt.BorderLayout());
        pa_mis1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 240, -1));

        btn_do3.setBackground(new java.awt.Color(73, 59, 59));
        btn_do3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_do3MousePressed(evt);
            }
        });
        btn_do3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/gift (2).png"))); // NOI18N
        btn_do3.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 29, 44));

        jLabel47.setBackground(new java.awt.Color(54, 33, 89));
        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(204, 204, 204));
        jLabel47.setText("المكافأت");
        btn_do3.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, -1, -1));

        pa_mis1.add(btn_do3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 230, -1));

        btn_inc3.setBackground(new java.awt.Color(73, 59, 59));
        btn_inc3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_inc3MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_inc3MousePressed(evt);
            }
        });
        btn_inc3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/hand0.png"))); // NOI18N
        btn_inc3.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, -1, 44));

        jLabel65.setBackground(new java.awt.Color(54, 33, 89));
        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(204, 204, 204));
        jLabel65.setText("الخصومات");
        btn_inc3.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 11, -1, -1));

        pa_mis1.add(btn_inc3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 230, -1));

        jSeparator4.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        pa_mis1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 170, 10));

        btn_ad5.setBackground(new java.awt.Color(73, 59, 59));
        btn_ad5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_ad5MousePressed(evt);
            }
        });

        jLabel78.setBackground(new java.awt.Color(54, 33, 89));
        jLabel78.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(204, 204, 204));
        jLabel78.setText("المكافأت والخصومات");

        javax.swing.GroupLayout btn_ad5Layout = new javax.swing.GroupLayout(btn_ad5);
        btn_ad5.setLayout(btn_ad5Layout);
        btn_ad5Layout.setHorizontalGroup(
            btn_ad5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_ad5Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        btn_ad5Layout.setVerticalGroup(
            btn_ad5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btn_ad5Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addComponent(jLabel78)
                .addContainerGap())
        );

        pa_mis1.add(btn_ad5, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 19, 200, -1));

        jp_rew_att.add(pa_mis1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 0, 230, 420));

        jLabel73.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(73, 59, 59));
        jLabel73.setText("الاسم");

        jTextField18_rew.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField18_rew.setForeground(new java.awt.Color(73, 59, 59));
        jTextField18_rew.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(73, 59, 59));
        jLabel75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/gift (3).png"))); // NOI18N
        jLabel75.setText("المكافأت");

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(73, 59, 59));
        jLabel76.setText("التاريخ");

        jTextField21_rew.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField21_rew.setForeground(new java.awt.Color(73, 59, 59));
        jTextField21_rew.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel79.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(73, 59, 59));
        jLabel79.setText("القيمة");

        jTextField22_rew.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField22_rew.setForeground(new java.awt.Color(73, 59, 59));
        jTextField22_rew.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel80.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(73, 59, 59));
        jLabel80.setText("رقم الموظف");

        jComboBox1_rew.setBackground(new java.awt.Color(73, 59, 59));
        jComboBox1_rew.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/multiply.png"))); // NOI18N
        jButton15.setBorder(null);
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/add (1).png"))); // NOI18N
        jButton16.setBorder(null);
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jComboBox5.setBackground(new java.awt.Color(73, 59, 59));
        jComboBox5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        javax.swing.GroupLayout jpa_rewLayout = new javax.swing.GroupLayout(jpa_rew);
        jpa_rew.setLayout(jpa_rewLayout);
        jpa_rewLayout.setHorizontalGroup(
            jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpa_rewLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_rewLayout.createSequentialGroup()
                        .addComponent(jLabel75)
                        .addGap(230, 230, 230))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_rewLayout.createSequentialGroup()
                        .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField18_rew, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField22_rew, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_rewLayout.createSequentialGroup()
                                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(82, 82, 82)
                                .addComponent(jComboBox1_rew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jTextField21_rew, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel79)
                            .addComponent(jLabel80)
                            .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel73)
                                .addComponent(jLabel76)))
                        .addGap(173, 173, 173))))
            .addGroup(jpa_rewLayout.createSequentialGroup()
                .addGap(196, 196, 196)
                .addComponent(jButton15)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jpa_rewLayout.createSequentialGroup()
                    .addGap(244, 244, 244)
                    .addComponent(jButton16)
                    .addContainerGap(275, Short.MAX_VALUE)))
        );
        jpa_rewLayout.setVerticalGroup(
            jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpa_rewLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel75)
                .addGap(55, 55, 55)
                .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel73)
                    .addComponent(jTextField18_rew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField21_rew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel76))
                .addGap(18, 18, 18)
                .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel80)
                    .addComponent(jComboBox1_rew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel79)
                    .addComponent(jTextField22_rew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton15)
                .addGap(27, 27, 27))
            .addGroup(jpa_rewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_rewLayout.createSequentialGroup()
                    .addContainerGap(362, Short.MAX_VALUE)
                    .addComponent(jButton16)
                    .addGap(25, 25, 25)))
        );

        jp_rew_att.add(jpa_rew, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 420));

        jLabel81.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel81.setForeground(new java.awt.Color(73, 59, 59));
        jLabel81.setText("الاسم");

        jTextField23_att.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField23_att.setForeground(new java.awt.Color(73, 59, 59));
        jTextField23_att.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel82.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(73, 59, 59));
        jLabel82.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/hand.png"))); // NOI18N
        jLabel82.setText("الخصومات");

        jLabel83.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(73, 59, 59));
        jLabel83.setText("التاريخ");

        jTextField24_att.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField24_att.setForeground(new java.awt.Color(73, 59, 59));
        jTextField24_att.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel84.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(73, 59, 59));
        jLabel84.setText("القيمة");

        jTextField25_att.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jTextField25_att.setForeground(new java.awt.Color(73, 59, 59));
        jTextField25_att.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel85.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel85.setForeground(new java.awt.Color(73, 59, 59));
        jLabel85.setText("رقم الموظف");

        jComboBox4.setBackground(new java.awt.Color(73, 59, 59));
        jComboBox4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/multiply.png"))); // NOI18N
        jButton17.setBorder(null);
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_fiynily/images/add (1).png"))); // NOI18N
        jButton18.setBorder(null);
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jComboBox6.setBackground(new java.awt.Color(73, 59, 59));
        jComboBox6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        javax.swing.GroupLayout jpa_attLayout = new javax.swing.GroupLayout(jpa_att);
        jpa_att.setLayout(jpa_attLayout);
        jpa_attLayout.setHorizontalGroup(
            jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpa_attLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_attLayout.createSequentialGroup()
                        .addComponent(jLabel82)
                        .addGap(230, 230, 230))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_attLayout.createSequentialGroup()
                        .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField23_att, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField24_att, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField25_att, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpa_attLayout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel84)
                            .addComponent(jLabel85)
                            .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel81)
                                .addComponent(jLabel83)))
                        .addGap(173, 173, 173))))
            .addGroup(jpa_attLayout.createSequentialGroup()
                .addGap(196, 196, 196)
                .addComponent(jButton17)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jpa_attLayout.createSequentialGroup()
                    .addGap(244, 244, 244)
                    .addComponent(jButton18)
                    .addContainerGap(273, Short.MAX_VALUE)))
        );
        jpa_attLayout.setVerticalGroup(
            jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpa_attLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel82)
                .addGap(55, 55, 55)
                .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel81)
                    .addComponent(jTextField23_att, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField24_att, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel83))
                .addGap(18, 18, 18)
                .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel85)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel84)
                    .addComponent(jTextField25_att, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addComponent(jButton17)
                .addGap(27, 27, 27))
            .addGroup(jpa_attLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpa_attLayout.createSequentialGroup()
                    .addContainerGap(362, Short.MAX_VALUE)
                    .addComponent(jButton18)
                    .addGap(25, 25, 25)))
        );

        jp_rew_att.add(jpa_att, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 420));

        bg.add(jp_rew_att, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 780, 420));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bgFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_bgFocusLost
  
    }//GEN-LAST:event_bgFocusLost
 
               public void show_user(){
ArrayList<User> list = userList();
DefaultTableModel model = (DefaultTableModel) jt_sal.getModel();


Object [] row = new Object [5];
for (int i=0; i<list.size();i++){
row[0]=list.get(i). getSal_id();
row[1]=list.get(i).getSal_name();
row[2]=list.get(i).getSal_amo();
row[3]=list.get(i).getSal_rew();
row[4]=list.get(i).getSal_tra();
    model.addRow(row);
}}
  
  
     public ArrayList<User> userList(){

ArrayList<User> usersList = new ArrayList<>();  

try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
String query1="Select * from Salary1";
Statement st = con.createStatement();
ResultSet rs=st.executeQuery(query1);
User user;
while (rs.next()) {
user= new User(rs.getInt("sal_id"), rs.getString("Sal_name"),rs.getFloat("Sal_amo"),rs.getFloat("Sal_rew"),rs.getFloat("Sal_tra"));
usersList.add(user);
}
}
catch (Exception e){

JOptionPane.showMessageDialog(null,e);
}
return usersList;
}

    
    private void btn_adMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_adMousePressed
        //   resrtVisible(p_sal);
//        pa_mis_sea_all.setVisible(false);
   pa_Benefits.setVisible(false);
         pa_mis_sea.setVisible(false);
           pa_mis_del.setVisible(false);
        pa_sal.setVisible(false);
         pa_emp.setVisible(false);
         pa_miss_h.setVisible(true); 
         jLabel7.setText("الوظائف");
         //  jPanel1.setVisible(true);
            pa_mis_add.setVisible(false); 
             jp_rew_att.setVisible(false);
        setColorr(btn_ad);
       
     
        resrtColorr(btn_com);
        resrtColorr(btn_em);
        resrtColorr(btn_inc);
        resrtColorr(btn_do);
        
    }//GEN-LAST:event_btn_adMousePressed

    private void btn_comMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_comMousePressed
        // resrtVisible(p_emp);
        // setVisible(p_emp);
           pa_Benefits.setVisible(false);
               pa_miss_h.setVisible(false);
          pa_sal.setVisible(false);
          pa_emp.setVisible(true);
        setColorr(btn_com);
//        jLabel7.setText("الموظفين");
        resrtColorr(btn_em);
        resrtColorr(btn_inc);
        resrtColorr(btn_ad);
        resrtColorr(btn_do);
    }//GEN-LAST:event_btn_comMousePressed

    private void btn_incMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_incMousePressed
        // resrtVisible(p_emp); 
            pa_Benefits.setVisible(false);
               pa_miss_h.setVisible(false);
         pa_emp.setVisible(false);
          pa_sal.setVisible(false);
        pa_sal.setVisible(false);
        jp_rew_att.setVisible(true);
             jpa_rew.setVisible(false);
             jpa_att.setVisible(false);
        
        jLabel7.setText("االمكافأت والخصومات");
        setColorr(btn_inc); 
      clear_text_rew();
        resrtColorr(btn_com);
        resrtColorr(btn_em);
        resrtColorr(btn_ad);
        resrtColorr(btn_do);
    }//GEN-LAST:event_btn_incMousePressed

    private void btn_emMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_emMousePressed
        // resrtVisible(p_emp);
               pa_miss_h.setVisible(false);
         pa_emp.setVisible(false);   jLabel7.setText("الرئيسية");
          jp_rew_att.setVisible(false);
        setColorr(btn_em);
     
        resrtColorr(btn_inc);
        resrtColorr(btn_com);
        resrtColorr(btn_ad);
        resrtColorr(btn_do);
        pa_Benefits.setVisible(true);
    }//GEN-LAST:event_btn_emMousePressed

    private void btn_doMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_doMousePressed
        //  p_sal1.setVisible(true);
           pa_Benefits.setVisible(false);
    DefaultTableModel mode7 = (DefaultTableModel) jt_sal.getModel();
               pa_miss_h.setVisible(false);
                jp_rew_att.setVisible(false);
       pa_sal.setVisible(true);     mode7.setRowCount(0);
       show_user();
     
     
  
//       DefaultTableModel model = (DefaultTableModel) jt_sal.getModel();
//model.setRowCount(0);

       jLabel7.setText("الرواتب");     //  setVisible(p_sal);
 
    
        claertext();
    setColorr(btn_do);
        resrtColorr(btn_com);
        resrtColorr(btn_em);
        resrtColorr(btn_inc);
        resrtColorr(btn_ad);
       
        //******************     sql *************

    }//GEN-LAST:event_btn_doMousePressed

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        int del = JOptionPane.showConfirmDialog(null, "Do you want to delete", "Delete",JOptionPane.YES_NO_OPTION);
        if(del ==0){
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
                Connection con = DriverManager.getConnection(url);
                int row = jt_sal.getSelectedRow();
                String value = (jt_sal.getModel().getValueAt(row,0).toString());
                String query ="Delete from Salary1 where Sal_id="+value;
                PreparedStatement pst = con.prepareStatement(query);
                pst.executeUpdate();
                DefaultTableModel model = (DefaultTableModel)jt_sal.getModel();
                model.setRowCount(0);
                show_user();
                JOptionPane.showMessageDialog(null,"Deleted");

            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
            Connection con = DriverManager.getConnection(url);

            int row = jt_sal.getSelectedRow();

            String value= (jt_sal.getModel().getValueAt(row,0).toString());
            String query = "update Salary1 set Sal_name=?, Sal_amo=?, Sal_rew=?,Sal_tra=? where Sal_id="+value;

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, jTextField4.getText());
            pst.setString(2,jTextField5.getText());
            pst.setString(3,jTextField6.getText());
            pst.setString(4,jTextField7.getText());
            //Integer.valueOf(jPasswordField1.getText()).intValue()

            pst.executeUpdate();

            ////////////
            DefaultTableModel model = (DefaultTableModel) jt_sal.getModel();
            model.setRowCount(0);
            show_user();
            ////////////
            JOptionPane.showMessageDialog(null,"Successfully inserted in DB" );
        }

        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
            Connection con = DriverManager.getConnection(url);

            String query ="insert into Salary1 (Sal_name,Sal_amo,Sal_rew,Sal_tra) values (?,?,?,?) ";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, jTextField4.getText());
            pst.setString(2,jTextField5.getText());
            pst.setString(3,jTextField6.getText());
            pst.setString(4,jTextField7.getText());
            //Integer.valueOf(jPasswordField1.getText()).intValue()

            pst.executeUpdate();

            ////////////
            DefaultTableModel model = (DefaultTableModel) jt_sal.getModel();
            model.setRowCount(0);
            show_user();
            ////////////
            JOptionPane.showMessageDialog(null,"Successfully inserted in DB" );
            claertext();

        }

        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        claertext();
    }//GEN-LAST:event_jButton2ActionPerformed

    public void get_mis_id(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);

          String query ="select Mis_id from Missions1";
            PreparedStatement pst=con.prepareStatement(query);
             ResultSet rs=pst.executeQuery();
             while(rs.next()){
                 int id=rs.getInt("Mis_id");
                 String id_to=Integer.toString(id);
               jComboBox3.addItem(id_to);
                 
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
     public void get_mis_name(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);

          String query ="select Mis_name from Missions1";
            PreparedStatement pst=con.prepareStatement(query);
             ResultSet rs=pst.executeQuery();
             while(rs.next()){
                  String  name=rs.getString("Mis_name");
            
               jComboBox2.addItem(name);
                 
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
    private void btn_do1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_do1MousePressed
       setColorr(btn_do1);
    pa_em_sea.setVisible(false);
    pa_d_emp.setVisible(false);
      pa_add_new_emp.setVisible(true);
     get_mis_id();
   //  get_mis_name();
    //    resrtColorr(btn_com1);
        resrtColorr(btn_em1);
        resrtColorr(btn_inc1);
        resrtColorr(btn_ad1);
       
    }//GEN-LAST:event_btn_do1MousePressed

    private void btn_em1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_em1MousePressed
  pa_add_new_emp.setVisible(false); 
        setColorr(btn_em1);
   
        resrtColorr(btn_inc1);
      //  resrtColorr(btn_com1);
        resrtColorr(btn_ad1);
        resrtColorr(btn_do1);
    }//GEN-LAST:event_btn_em1MousePressed

    private void btn_inc1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inc1MousePressed
  pa_add_new_emp.setVisible(false); 
     pa_em_sea.setVisible(false);
          pa_d_emp.setVisible(true);
        setColorr(btn_inc1);    
                DefaultTableModel mode8 = (DefaultTableModel) jTable8.getModel();
mode8.setRowCount(0);
    mode8.setRowCount(0);
    show_emp_delet();
       // resrtColorr(btn_com1);
        resrtColorr(btn_em1);
        resrtColorr(btn_ad1);
        resrtColorr(btn_do1);
    }//GEN-LAST:event_btn_inc1MousePressed
 public ArrayList<Emp>  empList(){

ArrayList<Emp> empList = new ArrayList<>();  


try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url2="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url2);
String query1="Select * from Employe1 ";
Statement stt = con.createStatement();
ResultSet rs2=stt.executeQuery(query1);
Emp emp;
while (rs2.next()) {

emp=new Emp(rs2.getInt("Emp_id"),rs2.getString("Emp_name"),
        rs2.getDate("Emp_bd"), rs2.getString("Emp_gn"),rs2.getInt("Mis_id"),
        rs2.getFloat("Emp_amo"),rs2.getDate("Emp_dec"),rs2.getDate("Emp_eff"),
        rs2.getInt("Emp_id_card"),rs2.getString("Emp_nat"), rs2.getString("Emp_qua"));
        empList.add(emp);
}
}
catch (Exception e){

JOptionPane.showMessageDialog(null,e);
}
return empList;
}
 
 
           public void show_emp(){
ArrayList<Emp> list2 = empList();
DefaultTableModel mode3 = (DefaultTableModel) jTable7.getModel();
Object [] row2 = new Object [11];
for (int j=0; j<list2.size();j++){
row2[0]=list2.get(j). getEmp_id();
row2[1]=list2.get(j).getEmp_name();
row2[2]=list2.get(j).getEmp_bd();
row2[3]=list2.get(j).getEmp_gn();
row2[4]=list2.get(j).getMis_id();
row2[5]=list2.get(j).getEmp_amo();
row2[6]=list2.get(j).getEmp_dec();
row2[7]=list2.get(j).getEmp_eff();
row2[8]=list2.get(j).getEmp_id_card();
row2[9]=list2.get(j).getEmp_nat();
row2[10]=list2.get(j).getEmp_qua();
mode3.addRow(row2);
}}
                      public void show_emp_delet(){
ArrayList<Emp> list2 = empList();
DefaultTableModel mode3 = (DefaultTableModel) jTable8.getModel();
Object [] row2 = new Object [11];
for (int j=0; j<list2.size();j++){
row2[0]=list2.get(j). getEmp_id();
row2[1]=list2.get(j).getEmp_name();
row2[2]=list2.get(j).getEmp_bd();
row2[3]=list2.get(j).getEmp_gn();
row2[4]=list2.get(j).getMis_id();
row2[5]=list2.get(j).getEmp_amo();
row2[6]=list2.get(j).getEmp_dec();
row2[7]=list2.get(j).getEmp_eff();
row2[8]=list2.get(j).getEmp_id_card();
row2[9]=list2.get(j).getEmp_nat();
row2[10]=list2.get(j).getEmp_qua();
mode3.addRow(row2);
}}
           /// search from table employe 
    private void btn_ad1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_ad1MousePressed
  pa_add_new_emp.setVisible(false);
  pa_d_emp.setVisible(false);
   pa_em_sea.setVisible(true);
 
   
        setColorr(btn_ad1);
        DefaultTableModel mode7 = (DefaultTableModel) jTable7.getModel();
mode7.setRowCount(0);
    mode7.setRowCount(0);
        show_emp(); 
       
    
      //  resrtColorr(btn_com1);
        resrtColorr(btn_em1);
        resrtColorr(btn_inc1);
        resrtColorr(btn_do1);
    }//GEN-LAST:event_btn_ad1MousePressed

    
    
    private void jt_salMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jt_salMouseClicked

        int i = jt_sal.getSelectedRow();
TableModel model = jt_sal.getModel();
jTextField4.setText(model.getValueAt(i,1).toString());
jTextField5.setText(model.getValueAt(i,2).toString());
jTextField6.setText(model.getValueAt(i,3).toString());
//jTextField7.setText(model.getValueAt(i,4).toString());
jTextField7.setText(model.getValueAt(i,4).toString());
//String gender =(model.getValueAt(i,3).toString());



        
    }//GEN-LAST:event_jt_salMouseClicked

    private void btn_com1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_com1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_com1MousePressed
 public void get_mis_id_(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);

          String query ="select Mis_id from Missions1";
            PreparedStatement pst=con.prepareStatement(query);
             ResultSet rs=pst.executeQuery();
             while(rs.next()){
                 int id=rs.getInt("Mis_id");
                 String id_to=Integer.toString(id);
               jcom_mis_id.addItem(id_to);
                 
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
    private void btn_do2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_do2MousePressed
//pa_mis_sea_all.setVisible(false);
        pa_mis_sea.setVisible(false);
        pa_mis_del.setVisible(false);
        setColorr(btn_do2);
      
       // resrtColorr(btn_em2);
        resrtColorr(btn_inc2);
        resrtColorr(btn_ad2);   
        pa_mis_add.setVisible(true);
        get_mis_id_();
 
    }//GEN-LAST:event_btn_do2MousePressed
//  Missions 
     
    public ArrayList<Missions> MissionsList(){

ArrayList<Missions> Missions1List = new ArrayList<>();  

try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
String query1="Select * from Missions1 ";

Statement st = con.createStatement();
ResultSet rs=st.executeQuery(query1);
Missions missions;
while (rs.next()) {
missions= new Missions(rs.getInt("Mis_id"), rs.getString("Mis_name"),rs.getInt("Sal_id"));
Missions1List.add(missions);
}
}
catch (Exception e){

JOptionPane.showMessageDialog(null,e);
}
return Missions1List;
}
    
  
    
    public void show_Missions(){
ArrayList<Missions> list55 = MissionsList();
DefaultTableModel mode55 = (DefaultTableModel) jt12.getModel();
Object [] row55 = new Object [3];
for (int r=0; r<list55.size();r++){
row55[0]=list55.get(r).getMis_id();
row55[1]=list55.get(r).getMis_name();
row55[2]=list55.get(r).getSal_id();

mode55.addRow(row55);

}
    }
    
    
    
    private void btn_inc2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inc2MousePressed
//        pa_mis_sea_all.setVisible(false);
        pa_mis_add.setVisible(false); 
         pa_mis_del.setVisible(true);
        setColorr(btn_inc2); 
                      DefaultTableModel mode8 = (DefaultTableModel) jt12.getModel();

    mode8.setRowCount(0);
          
    //    resrtColorr(btn_em2);
        resrtColorr(btn_ad2);
        resrtColorr(btn_do2);
      show_Missions();
    }//GEN-LAST:event_btn_inc2MousePressed
    public ArrayList<Missions_all> MissionsList_saerch(){

ArrayList<Missions_all> Missions1List_ = new ArrayList<>();  

try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
String query1="select Employe1.Emp_name ,Employe1.Mis_id,Missions1.Mis_name from Employe1,Missions1";
//JOptionPane.showMessageDialog(null, "10");
Statement st = con.createStatement();
ResultSet rs=st.executeQuery(query1);
Missions_all missions_all;
while (rs.next()) {
missions_all=new Missions_all(rs.getString("Emp_name"),rs.getInt("Mis_id"),rs.getString("Mis_name"));
Missions1List_.add(missions_all);
}

}
catch (Exception e){

JOptionPane.showMessageDialog(null,e);
}
return Missions1List_;
}
   
    
    
    public void show_Missions_saerch_all(){
ArrayList<Missions_all> list66 = MissionsList_saerch();
DefaultTableModel mode66 = (DefaultTableModel) jt_sea_mis_all.getModel();
Object [] row66 = new Object [3];
for (int m=0; m<list66.size();m++){
row66[0]=list66.get(m).getEmp_name();
row66[1]=list66.get(m).getMis_id();
row66[2]=list66.get(m).getMis_name();
mode66.addRow(row66);

}
    }
    private void btn_ad2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_ad2MousePressed
//pa_mis_sea_all.setVisible(false);
        pa_mis_add.setVisible(false); 
     pa_mis_del.setVisible(false);
     pa_mis_sea.setVisible(true);
        setColorr(btn_ad2);
       
     
      
       // resrtColorr(btn_em2);
        resrtColorr(btn_inc2);
      resrtColorr(btn_do2);
show_Missions_saerch_all();
    }//GEN-LAST:event_btn_ad2MousePressed

    private void btn_ad3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_ad3MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_ad3MousePressed

    private void btn_inc2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inc2MouseExited
        // TODO add your handling code here:
   
    }//GEN-LAST:event_btn_inc2MouseExited

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      jTextField8.setText(null);
      jTextField9.setText(null);
      jTextField10.setText(null);
      jTextField11.setText(null);
jTextField12.setText(null);
jTextField13.setText(null);
   jCheckBox1.setSelected(false);
      jCheckBox2.setSelected(false);
      jCheckBox3.setSelected(false);
         jCheckBox4.setSelected(false);
      jCheckBox5.setSelected(false);
      jRadioButton1.setSelected(false);
      jRadioButton2.setSelected(false);
      jRadioButton1.setEnabled(true);
      jRadioButton2.setEnabled(true);
      
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
       jRadioButton2.setEnabled(false);
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
         jRadioButton1.setEnabled(false);
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
       pa_add_new_emp.setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
            try {
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
          String query ="insert into Employe1 (Emp_name,Emp_bd,Emp_gn,Mis_id,Emp_amo,Emp_dec,Emp_eff,Emp_id_card,Emp_nat,Emp_qua) values (?,?,?,?,?,?,?,?,?,?) ";
          PreparedStatement pst = con.prepareStatement(query);
pst.setString(1, jTextField8.getText());
pst.setString(2,jTextField9.getText());
//Integer.valueOf(jPasswordField1.getText()).intValue()
if (jRadioButton1.isSelected()){
 gender = "ذكر";
}
 
if (jRadioButton2.isSelected()){

gender = "انثى";
}
pst.setString(3,gender);
 String major;
 major = jComboBox3.getSelectedItem().toString();
 pst.setString(4, major);

pst.setString(5,jTextField10.getText());
pst.setString(6,jTextField11.getText());
pst.setString(7,jTextField12.getText());
pst.setString(8,jTextField13.getText());
pst.setString(9,jTextField16.getText());
 String fs="";
 if (jCheckBox1.isSelected()){
 
 fs+=jCheckBox1.getText()+ "  ";
 }
 if (jCheckBox2.isSelected()){
 
 fs+=jCheckBox2.getText()+ "  ";
 }
  if (jCheckBox3.isSelected()){
 
 fs+=jCheckBox3.getText()+ "  ";
 }
   if (jCheckBox4.isSelected()){
 
 fs+=jCheckBox4.getText()+ "  ";
 }
    if (jCheckBox5.isSelected()){
 
 fs+=jCheckBox5.getText()+ "  ";
 }
 pst.setString(10, fs);
 
 

 pst.executeUpdate();
 
 
 ////////////
///DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
//model.setRowCount(0);
//show_user();
////////////
 JOptionPane.showMessageDialog(null,"Successfully inserted in DB" );

 
             }
             
            
             
             
             
             
catch(Exception e) {
JOptionPane.showMessageDialog(null, e);
}
     
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
    
     
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
       /*       try{
                  String sel=jComboBox3.getSelectedItem().toString();
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);

          String query ="select Mis_name from Missions1 where Mis_id="+sel;
            PreparedStatement pst=con.prepareStatement(query);
             ResultSet rs=pst.executeQuery();
             while(rs.next()){
                  String  name=rs.getString("Mis_id");
            
               jComboBox2.addItem(name);
                 
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        JOptionPane.showMessageDialog(null, jComboBox2.getSelectedItem().toString());*/
    }//GEN-LAST:event_jComboBox3ActionPerformed

//    public ArrayList<Emp>  emp_sea_List(){
//
//ArrayList<Emp>  emp_sea_List = new ArrayList<>();  
//
//
//try{
//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//String url4="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
//Connection con = DriverManager.getConnection(url4);
//String query4="Select * from Employe1 where Emp_name= ? ";
//Statement stt4 = con.createStatement();
//
//ResultSet rs4=stt4.executeQuery(query4);
//Emp emp;
//while (rs4.next()) {
////emp= new User(rs.getInt("sal_id"), rs.getString("Sal_name"),rs.getFloat("Sal_amo"),rs.getFloat("Sal_rew"),rs.getFloat("Sal_tra"));
//
//emp=new Emp(rs4.getInt("Emp_id"),rs4.getString("Emp_name"),
//        rs4.getDate("Emp_bd"), rs4.getString("Emp_gn"),rs4.getInt("Mis_id"),
//        rs4.getFloat("Emp_amo"),rs4.getDate("Emp_dec"),rs4.getDate("Emp_eff"),
//        rs4.getInt("Emp_id_card"),rs4.getString("Emp_nat"), rs4.getString("Emp_qua"));
//         emp_sea_List.add(emp);
//}
//}
//catch (Exception e){
//
//JOptionPane.showMessageDialog(null,e);
//}
//return  emp_sea_List;
//}
// 
// 
//           public void show_emp_search(){
//ArrayList<Emp> list4 =  emp_sea_List();
//DefaultTableModel mode4 = (DefaultTableModel) jTable7.getModel();
//mode4.setRowCount(0);
//Object [] row4 = new Object [11];
////for (int k=0; k<list4.size();k++){
//int k=1;
//row4[0]=list4.get(k). getEmp_id();
//row4[1]=list4.get(k).getEmp_name();
//row4[2]=list4.get(k).getEmp_bd();
//row4[3]=list4.get(k).getEmp_gn();
//row4[4]=list4.get(k).getMis_id();
//row4[5]=list4.get(k).getEmp_amo();
//row4[6]=list4.get(k).getEmp_dec();
//row4[7]=list4.get(k).getEmp_eff();
//row4[8]=list4.get(k).getEmp_id_card();
//row4[9]=list4.get(k).getEmp_nat();
//row4[10]=list4.get(k).getEmp_qua();
//mode4.addRow(row4);
////}
//}
    //**************************//
                                      
 public ArrayList<Emp>  empList__ser(){

ArrayList<Emp> empList = new ArrayList<>();  


try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url2="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url2);
String se=jTextField15.getText();
String query1="Select * from Employe1 where Emp_name ="+se;
Statement stt = con.createStatement();
ResultSet rs2=stt.executeQuery(query1);
Emp emp;
while (rs2.next()) {

emp=new Emp(rs2.getInt("Emp_id"),rs2.getString("Emp_name"),
        rs2.getDate("Emp_bd"), rs2.getString("Emp_gn"),rs2.getInt("Mis_id"),
        rs2.getFloat("Emp_amo"),rs2.getDate("Emp_dec"),rs2.getDate("Emp_eff"),
        rs2.getInt("Emp_id_card"),rs2.getString("Emp_nat"), rs2.getString("Emp_qua"));
        empList.add(emp);
}
}
catch (Exception e){

JOptionPane.showMessageDialog(null,e);
}
return empList;
}
 
 
           public void show_emp__ser(){
ArrayList<Emp> list2 = empList();
DefaultTableModel mode3 = (DefaultTableModel) jTable7.getModel();
Object [] row2 = new Object [11];
for (int j=0; j<list2.size();j++){
row2[0]=list2.get(j). getEmp_id();
row2[1]=list2.get(j).getEmp_name();
row2[2]=list2.get(j).getEmp_bd();
row2[3]=list2.get(j).getEmp_gn();
row2[4]=list2.get(j).getMis_id();
row2[5]=list2.get(j).getEmp_amo();
row2[6]=list2.get(j).getEmp_dec();
row2[7]=list2.get(j).getEmp_eff();
row2[8]=list2.get(j).getEmp_id_card();
row2[9]=list2.get(j).getEmp_nat();
row2[10]=list2.get(j).getEmp_qua();
mode3.addRow(row2);
}}
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
 try{
       Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url2="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url2);
        String sql="Select * from Employe1 where Emp_name=? ";
        PreparedStatement pst=con.prepareStatement(sql);
        DefaultTableModel mode3 = (DefaultTableModel) jTable7.getModel();
        pst.setString(1, jTextField15.getText());
     mode3.setRowCount(0);
        ResultSet rs=pst.executeQuery();
        if(rs.next()){
        
ArrayList<Emp> list2 = empList();

    
Object [] row2 = new Object [11];
for (int j=0; j<list2.size();j++){
row2[0]=list2.get(j). getEmp_id();
row2[1]=list2.get(j).getEmp_name();
row2[2]=list2.get(j).getEmp_bd();
row2[3]=list2.get(j).getEmp_gn();
row2[4]=list2.get(j).getMis_id();
row2[5]=list2.get(j).getEmp_amo();
row2[6]=list2.get(j).getEmp_dec();
row2[7]=list2.get(j).getEmp_eff();
row2[8]=list2.get(j).getEmp_id_card();
row2[9]=list2.get(j).getEmp_nat();
row2[10]=list2.get(j).getEmp_qua();
mode3.addRow(row2);
}
        }else{
            JOptionPane.showMessageDialog(null, "الاتصال غير ناجح");
           
        }
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, e);
    }
   
           
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jTable7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable7MouseClicked

        int i = jt_sal.getSelectedRow();
        TableModel model = jt_sal.getModel();
        jTextField4.setText(model.getValueAt(i,1).toString());
        jTextField5.setText(model.getValueAt(i,2).toString());
        jTextField6.setText(model.getValueAt(i,2).toString());
        jTextField7.setText(model.getValueAt(i,2).toString());
        String gender =(model.getValueAt(i,3).toString());
    }//GEN-LAST:event_jTable7MouseClicked

    private void jTable8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable8MouseClicked

    private void btn_inc1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inc1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_inc1MouseExited

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        

             
 int del = JOptionPane.showConfirmDialog(null, "هل تريد الحذف", "حذف",JOptionPane.YES_NO_OPTION);
if(del ==0){
        try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
int row = jTable8.getSelectedRow();
String value = (jTable8.getModel().getValueAt(row,0).toString());
String query ="Delete from Employe1 where Emp_id="+value;
PreparedStatement pst = con.prepareStatement(query);
pst.executeUpdate();
DefaultTableModel model = (DefaultTableModel)jTable8.getModel();
model.setRowCount(0);
   show_emp_delet();
JOptionPane.showMessageDialog(null,"تم الحذف");

    }                                                                         
catch(Exception e) {
JOptionPane.showMessageDialog(null, e);
}
}
            
        
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        
        
        try {
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
          String query ="insert into Missions1 (Mis_name,sal_id) values (?,?) ";
          PreparedStatement pst = con.prepareStatement(query);
pst.setString(1, jTextField17.getText());
pst.setString(2,jcom_mis_id.getSelectedItem().toString());
//Integer.valueOf(jPasswordField1.getText()).intValue()

 pst.executeUpdate();
 
 JOptionPane.showMessageDialog(null,"تم الحفظ بنجاح" );
  claerT17_20();

 
             }
             
            
             
             
             
             
catch(Exception e) {
JOptionPane.showMessageDialog(null, e);
}
        
    }//GEN-LAST:event_jButton11ActionPerformed
 void claerT17_20(){
    jTextField17.setText(null);
        jTextField20.setText(null);

}
    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        claerT17_20();
    }//GEN-LAST:event_jButton12ActionPerformed

    /// دالة ملى الكمبو بوكس با  رقم المرتبة
   public void add_comb_Mis_id() throws ClassNotFoundException{
        Statement st;
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
try{
    Connection con=DriverManager.getConnection(url);
    String sql="select Mis_id from Missions1";
    st=(Statement)con.createStatement();
    while(rs.next()){
        this.jcom_mis_id.addItem(rs.getString(rs.findColumn("Mis_id")));
    }
    
}catch(Exception e){
    JOptionPane.showMessageDialog(null, e);
}
        
    }
    private void jt12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jt12MouseClicked

        int i = jt12.getSelectedRow();
        TableModel model = jt12.getModel();
        jTextField4.setText(model.getValueAt(i,1).toString());
        jTextField5.setText(model.getValueAt(i,2).toString());
        jTextField6.setText(model.getValueAt(i,2).toString());
        jTextField7.setText(model.getValueAt(i,2).toString());
        String gender =(model.getValueAt(i,3).toString());
    }//GEN-LAST:event_jt12MouseClicked

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        
        int del = JOptionPane.showConfirmDialog(null, "هل تريد الحذف", "حذف",JOptionPane.YES_NO_OPTION);
        if(del ==0){
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
                Connection con = DriverManager.getConnection(url);
                int row = jt12.getSelectedRow();
                String value = (jt12.getModel().getValueAt(row,0).toString());
                String query ="Delete from Missions1 where Mis_id="+value;
                PreparedStatement pst = con.prepareStatement(query);
                pst.executeUpdate();
                DefaultTableModel model = (DefaultTableModel)jt12.getModel();
                model.setRowCount(0);
      
           show_Missions();
                JOptionPane.showMessageDialog(null,"تم الحذف بنجاح");

            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_jButton14ActionPerformed
int xx,xy;
    private void bgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bgMousePressed
        // TODO add your handling code here:
             xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_bgMousePressed

    private void bgMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bgMouseDragged
        // TODO add your handling code here:
            int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xx,y-xy);
    }//GEN-LAST:event_bgMouseDragged

    private void jt_sea_mis_allMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jt_sea_mis_allMouseClicked

        int i = jTable1.getSelectedRow();
        TableModel model = jTable1.getModel();
        jTextField4.setText(model.getValueAt(i,1).toString());
        jTextField5.setText(model.getValueAt(i,2).toString());
        jTextField6.setText(model.getValueAt(i,2).toString());
        jTextField7.setText(model.getValueAt(i,2).toString());
        String gender =(model.getValueAt(i,3).toString());
    }//GEN-LAST:event_jt_sea_mis_allMouseClicked

    private void btn_do3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_do3MousePressed
       setColorr(btn_do3);
     get_Emp_id();
     get_Emp_name();
        resrtColorr(btn_inc3);
         jpa_att.setVisible(false);
        jpa_rew.setVisible(true);
    }//GEN-LAST:event_btn_do3MousePressed

    private void btn_inc3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inc3MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_inc3MouseExited

    private void btn_inc3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inc3MousePressed
         setColorr(btn_inc3);
     
        resrtColorr(btn_do3);
         jpa_rew.setVisible(false);
         jpa_att.setVisible(true);
    }//GEN-LAST:event_btn_inc3MousePressed

    private void btn_ad5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_ad5MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_ad5MousePressed
  public void get_Emp_name(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);

          String query ="select Emp_name from Employe1";
            PreparedStatement pst=con.prepareStatement(query);
             ResultSet rs=pst.executeQuery();
             while(rs.next()){
                String id=rs.getString("Emp_name");
                // String id_to=Integer.toString(id);
                 
               jComboBox5.addItem(id);
                      jComboBox6.addItem(id);
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
    }
    public void clear_text_rew(){
        jTextField18_rew.setText(null);
           jTextField21_rew.setText(null);
              jTextField22_rew.setText(null);
    }
    public void get_Emp_id(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);

          String query ="select Emp_id from Employe1";
            PreparedStatement pst=con.prepareStatement(query);
             ResultSet rs=pst.executeQuery();
             while(rs.next()){
                 int id=rs.getInt("Emp_id");
                 String id_to=Integer.toString(id);
               jComboBox4.addItem(id_to);
                      jComboBox1_rew.addItem(id_to);
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
    }
    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
       try {
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
          String query ="insert into Rew (Rew__name,Rew_data,Emp_id,Rew_amo) values (?,?,?,?) ";
          PreparedStatement pst = con.prepareStatement(query);
pst.setString(1, jTextField18_rew.getText());
pst.setString(2,jTextField21_rew.getText());
pst.setString(3,jComboBox1_rew.getSelectedItem().toString());
pst.setString(4,jTextField22_rew.getText());

 

 pst.executeUpdate();
 
 
 ////////////
///DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
//model.setRowCount(0);
//show_user();
////////////
clear_text_rew();
 JOptionPane.showMessageDialog(null,"تم اضافة المكافئة بنجاح" );

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }    
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
 try {
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      String url="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con = DriverManager.getConnection(url);
          String query ="insert into Att (Att__name,Att_data,Emp_id,Att_amo) values (?,?,?,?) ";
          PreparedStatement pst = con.prepareStatement(query);
pst.setString(1, jTextField23_att.getText());
pst.setString(2,jTextField24_att.getText());
pst.setString(3,jComboBox4.getSelectedItem().toString());
pst.setString(4,jTextField25_att.getText());

 

 pst.executeUpdate();
 
 
 ////////////
///DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
//model.setRowCount(0);
//show_user();
////////////
clear_text_att();
 JOptionPane.showMessageDialog(null,"تم اضافة الخصم  بنجاح" );

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }     
             
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
clear_text_rew();    

    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
clear_text_att();      
    }//GEN-LAST:event_jButton17ActionPerformed
public void clear_text_att(){
    jTextField23_att.setText(null);
        jTextField24_att.setText(null);
            jTextField25_att.setText(null);
}
    // select from employe1 where emp_name= htext15****
       public ArrayList<Emp> empList_search_name(){

ArrayList<Emp> empList_searh_name = new ArrayList<>();  

try{
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

String url44="jdbc:sqlserver://localhost:1433;databaseName=db_HR;user=HR;password=HR";
Connection con44 = DriverManager.getConnection(url44);

String query144="Select * from test2 where id= " +jTextField15.getText();
Statement st = con44.createStatement();
ResultSet rs5=st.executeQuery(query144);
Emp emp44;
while (rs5.next()) {
emp44=new Emp(rs5.getInt("Emp_id"),rs5.getString("Emp_name"),
        rs5.getDate("Emp_bd"), rs5.getString("Emp_gn"),rs5.getInt("Mis_id"),
        rs5.getFloat("Emp_amo"),rs5.getDate("Emp_dec"),rs5.getDate("Emp_eff"),
        rs5.getInt("Emp_id_card"),rs5.getString("Emp_nat"), rs5.getString("Emp_qua"));
         empList_searh_name.add(emp44);
}
}
catch (Exception e){

JOptionPane.showMessageDialog(null,e);
}
return  empList_searh_name;
}
    
    
    public void show_empList_searh_name(){
ArrayList<Emp> list44 = empList();
DefaultTableModel mode44 = (DefaultTableModel) jTable7.getModel();


Object [] row44 = new Object [11];
//for (int k=0; k<list.size();k++){
int k=1;
row44[0]=list44.get(k). getEmp_id();
row44[1]=list44.get(k).getEmp_name();
row44[2]=list44.get(k).getEmp_bd();
row44[3]=list44.get(k).getEmp_gn();
row44[4]=list44.get(k).getMis_id();
row44[5]=list44.get(k).getEmp_amo();
row44[6]=list44.get(k).getEmp_dec();
row44[7]=list44.get(k).getEmp_eff();
row44[8]=list44.get(k).getEmp_id_card();
row44[9]=list44.get(k).getEmp_nat();
row44[10]=list44.get(k).getEmp_qua();
mode44.addRow(row44);
//}
    }
                               
  
        
    private void btn_ademMousePressed(java.awt.event.MouseEvent evt) {                                    
        // TODO add your handling code here:
    }   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bg;
    private javax.swing.JPanel btn_ad;
    private javax.swing.JPanel btn_ad1;
    private javax.swing.JPanel btn_ad2;
    private javax.swing.JPanel btn_ad3;
    private javax.swing.JPanel btn_ad5;
    private javax.swing.JPanel btn_com;
    private javax.swing.JPanel btn_com1;
    private javax.swing.JPanel btn_do;
    private javax.swing.JPanel btn_do1;
    private javax.swing.JPanel btn_do2;
    private javax.swing.JPanel btn_do3;
    private javax.swing.JPanel btn_em;
    private javax.swing.JPanel btn_em1;
    private javax.swing.JPanel btn_inc;
    private javax.swing.JPanel btn_inc1;
    private javax.swing.JPanel btn_inc2;
    private javax.swing.JPanel btn_inc3;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JComboBox<String> jComboBox1_rew;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTable8;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18_rew;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField21_rew;
    private javax.swing.JTextField jTextField22_rew;
    private javax.swing.JTextField jTextField23_att;
    private javax.swing.JTextField jTextField24_att;
    private javax.swing.JTextField jTextField25_att;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JComboBox<String> jcom_mis_id;
    private javax.swing.JPanel jp_rew_att;
    private javax.swing.JPanel jpa_att;
    private javax.swing.JPanel jpa_rew;
    private javax.swing.JTable jt12;
    private javax.swing.JTable jt_sal;
    private javax.swing.JTable jt_sea_mis_all;
    private javax.swing.JPanel pa_Benefits;
    private javax.swing.JPanel pa_add_new_emp;
    private javax.swing.JPanel pa_d_emp;
    private javax.swing.JPanel pa_em_sea;
    private javax.swing.JPanel pa_emp;
    private javax.swing.JPanel pa_mis;
    private javax.swing.JPanel pa_mis1;
    private javax.swing.JPanel pa_mis_add;
    private javax.swing.JPanel pa_mis_del;
    private javax.swing.JPanel pa_mis_sea;
    private javax.swing.JPanel pa_miss_h;
    private java.awt.Panel pa_sal;
    private javax.swing.JPanel s;
    private javax.swing.JPanel s1;
    // End of variables declaration//GEN-END:variables

   
}
