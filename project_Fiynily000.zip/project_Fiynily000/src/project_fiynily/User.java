/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_fiynily;

/**
 *
 * @author A2M
 */

    public class User {
    private int Sal_id;
private String Sal_name;
float Sal_amo,Sal_rew,Sal_tra;
public User (int Sal_id, String Sal_name, Float Sal_amo, Float Sal_rew,Float Sal_tar){
this.Sal_id=Sal_id;
this.Sal_name=Sal_name;
this.Sal_amo=Sal_amo;
this.Sal_rew=Sal_rew;
this.Sal_tra=Sal_tra;
}
public int getSal_id(){
return Sal_id;
}
public String getSal_name(){
return Sal_name;
}
public float getSal_amo(){
return Sal_amo;
}
public float getSal_rew(){
return Sal_rew;
}
public float getSal_tra(){
return Sal_tra;
}
}

    

